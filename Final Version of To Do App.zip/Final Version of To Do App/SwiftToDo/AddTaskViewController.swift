//
//  AddTaskViewController.swift
//  SwiftToDo
//
//  
//  Copyright © 2017 Karti. All rights reserved.
//  By: Kartihan Srisaravanapavan, Kushal Parmar, and Tin Tran

import UIKit

class AddTaskViewController: UIViewController {

    //Linking both textfields
    
    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var datePickerTxt: UITextField!
    
    let datePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createDatePicker()
    }
        // Do any additional setup after loading the view.
        
        func createDatePicker() {
            
            //Getting the actual dates at the bottom of the screen
            let toolbar = UIToolbar()
            toolbar.sizeToFit()
            
            //Button items
            let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
            toolbar.setItems([doneButton], animated: false)
            
            datePickerTxt.inputAccessoryView = toolbar
            
            //Assigning the date picker to the textfield
            datePickerTxt.inputView = datePicker
        }
    //Function when the done button is pressed
    func donePressed() {
        
        //Check if editing is done
        datePickerTxt.text = "\(datePicker.date)"
        self.view.endEditing(true)
    }
    
    //Function if button is pressed
    @IBAction func btnTapped(_ sender: Any) {
        
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        
        //Validation to check if all the information is filled out
        if textField.text == "" && datePickerTxt.text == ""{
            let alertController = UIAlertController(title: "Missing Inputs", message: "You need to fill out both fields first", preferredStyle: .alert)
           
            self.present(alertController, animated: true, completion: nil)
            
            let OkAction = UIAlertAction (title: "Ok", style: .default) { (action:UIAlertAction) in }
            
            alertController.addAction(OkAction)
           
            
        }else if textField.text == ""{
            let alertController = UIAlertController(title: "Missing Input", message: "Please fill out the name of the task", preferredStyle: .alert)
            
            self.present(alertController, animated: true, completion: nil)
            
            let OkAction = UIAlertAction (title: "Ok", style: .default) { (action:UIAlertAction) in }
            
            alertController.addAction(OkAction)
            
        
        }else if datePickerTxt.text == ""{
            let alertController = UIAlertController(title: "Missing Input", message: "Please pick a due date for the task", preferredStyle: .alert)
            
            self.present(alertController, animated: true, completion: nil)
            
            let OkAction = UIAlertAction (title: "Ok", style: .default) { (action:UIAlertAction) in }
            
            alertController.addAction(OkAction)
            
        }else{
        
        //Setting up the name and duedate with the context
        let task = Task(context: context)
        task.name = textField.text!
        task.duedate = datePickerTxt.text!
    
       
        //Saving the data to coredata
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        
        navigationController!.popViewController(animated: true)
            
        }
        
    }
    
}

































