//
//  ViewController.swift
//  SwiftToDo
//
//
//  Copyright © 2017 Karti. All rights reserved.
//  By: Kartihan Srisaravanapavan, Kushal Parmar, and Tin Tran

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    //New Array named tasks
    var tasks : [Task] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        //Get the data from coredata and then reload the table
        getData()
        
        tableView.reloadData()
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //Checks to see how many tasks there are
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //Getting the data from the two textboxes and putting them into a cell in the table
        let cell = UITableViewCell()
        
        let task = tasks[indexPath.row]
        
        //Adding both the name and date to the same cell
        cell.textLabel?.text = (task.name)!+"    "+(task.duedate!)
        
        return cell
    }
    
    func getData() {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        //Gets the data from the coredata
        do {
        tasks = try context.fetch(Task.fetchRequest())
        }
        catch {
            //Error if fails
            print("Fetching failed")
        }
        
    }
    
    //Deleting tasks
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        //Deleting a task (by swiping from the right to the left)
        if editingStyle == .delete {
            //Removes the task from the list and then moves everything else up by one
            let task = tasks[indexPath.row]
            context.delete(task)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
            do {
                tasks = try context.fetch(Task.fetchRequest())
            }
            catch {
                print("Fetching failed")
            }
        }
        //Table gets reloaded
        tableView.reloadData()
        
    }
    


}

